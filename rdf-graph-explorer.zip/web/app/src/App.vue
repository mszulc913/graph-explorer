<template>
  <div id="app" class="container">
    <explorer></explorer>
  </div>
</template>

<script>
import Explorer from './views/Explorer.vue'

export default {
  name: 'app',
  components: {
    Explorer
  }
}
</script>
